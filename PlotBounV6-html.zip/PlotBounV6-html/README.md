# Plot Boundary V6 — standalone HTML edition

**`PlotBoundaryV6.html` is the whole application.** Double-click it in any modern browser
(Edge, Chrome, Firefox). Nothing to install, no Python, no internet connection needed.

## What's new in V6

### Input units: pixels, meters, feet
When the orthomosaic has a projected CRS, **Meters** and **Feet** are both offered in *Input Units*
(rasters whose CRS is in feet are handled too). All dimensional fields, group fields and the origin readout follow the chosen unit.

### Plot Group Editor
* **Pick rows** — a third pick mode next to *Pick columns* and *Pick single plots*. Click a plot to add/remove its whole row.
  Row selections get the group's Shift, Plot Height and N-S Gap re-spacing (adjacent selected rows are re-spaced from the first one),
  exactly like columns get Plot Width and E-W Gap. A plot that is in a row group *and* a column group takes its X/width from the
  column group and its Y/height from the row group.
* **Apply edits** — each group has an *Apply edits* button. It bakes the group's current corrected geometry into the plots
  permanently, then empties the group so it can be reused for the next correction. Applied plots keep their shape when you
  clear or delete groups, change global geometry, or move the origin (they move with it). Further group edits on an applied
  plot work relative to its applied shape (shift, rotate around its center, resize from its anchor corner).
* Applied plots are drawn with a dashed outline so you can see which plots carry permanent edits. Only the applying group's
  own effect is baked; other groups that are still live keep applying on top, so nothing is counted twice.
* **Undo last apply** (restores the geometry *and* the group's selection and values, so you can adjust and re-apply) and
  **Reset all applied edits** buttons at the top of the section.
* Applied edits are stored in the project file and are pruned automatically if you later remove the rows, columns or trials they belong to.

### Trials that continue the previous grid
In the *Placed* list every trial after the first offers **Continuing Trial N (next cell after its last plot)**. Such a trial has no block
of its own: it carries on in Trial N's lattice, starting in the cell right after Trial N's last plot and wrapping into the next column
(column-wise numbering) or next row (row-wise numbering), serpentine included. It works when Trial N ends mid-column, and trials can
chain (Trial 3 continuing Trial 2). Rows/columns come from that grid; you only set **Plots in trial**.

### Flexible labeling per trial
* **Plots in trial** — when a trial has fewer plots than rows × columns (e.g. 15 plots on a 4 × 4 grid), enter the real
  number; the last plots in numbering order are not generated.
* **Continue numbering from the previous trial** — a checkbox so Trial 2 starts right after Trial 1's last ID, whatever it is.
* **Custom labels** — paste your own labels in numbering order (comma, space or newline separated). Numeric ranges such as
  `201-215` are expanded; text labels such as `A1` are allowed. Plots beyond the list continue with sequential numbers.
* Exports now carry both a numeric `ID` and a text `Label` (Shapefile: `ID` N10 + `Label` C32; GeoJSON / CSV / KML: both).

### Project files
* Loading a project now keeps the layout when you open the orthomosaic afterwards (previously opening the image re-centred the origin and discarded the loaded layout).
* After loading a project without an image open, the app immediately asks you to open the orthomosaic the project was made with.
* V3, V4, V5 and V6 project files all load.

## Carried over
Numbering along rows or columns; trials with their own rows/columns/start ID placed N/S/E/W of each other; multi-group editor with
columns, single plots, shift, rotation and plot size / gap overrides; GeoTIFF (incl. JPEG-compressed), PNG/JPEG + world file;
GeoJSON / Shapefile (.zip) / KML / CSV exports.

## Files
* `PlotBoundaryV6.html` — the app (single file, self-contained).
* `src/app-v6.html` — the app without the two inlined libraries (for editing).
* `lib/tiff-decoder.js`, `lib/vector-export.js` — the libraries (inlined into the HTML at build time).
