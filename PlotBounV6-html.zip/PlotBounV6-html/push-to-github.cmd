@echo off
REM Pushes this folder (Plot Boundary V6 standalone edition) to https://github.com/AliBgisrs/PlotBoundary-V5
REM Double-click to run. Requires git and a GitHub login (browser window or token prompt).
setlocal
cd /d "%~dp0" || (echo Folder not found & pause & exit /b 1)

if not exist PlotBoundaryV6.html (echo PlotBoundaryV6.html is missing - build not finished & pause & exit /b 1)

if not exist .git (
  git init || goto :fail
)
git branch -M main
git remote remove origin 2>nul
git remote add origin https://github.com/AliBgisrs/PlotBoundary-V5.git || goto :fail

git add PlotBoundaryV6.html README.md .gitignore src lib || goto :fail
git commit -m "Plot Boundary V6: feet units, row picking, apply/undo edits, project reload fix" || echo (nothing new to commit)

git fetch origin main 2>nul && git pull origin main --allow-unrelated-histories --no-edit --no-rebase

git push -u origin main || goto :fail
echo.
echo Done. Pushed to https://github.com/AliBgisrs/PlotBoundary-V5
pause
exit /b 0

:fail
echo.
echo Push failed - see the message above.
pause
exit /b 1
